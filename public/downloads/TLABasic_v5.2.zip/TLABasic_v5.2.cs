#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private DynamicTrendLine[] cacheDynamicTrendLine;
		private VWAP[] cacheVWAP;

		
		public DynamicTrendLine DynamicTrendLine(int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return DynamicTrendLine(Input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public VWAP VWAP()
		{
			return VWAP(Input);
		}


		
		public DynamicTrendLine DynamicTrendLine(ISeries<double> input, int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			if (cacheDynamicTrendLine != null)
				for (int idx = 0; idx < cacheDynamicTrendLine.Length; idx++)
					if (cacheDynamicTrendLine[idx].PeriodFastMA == periodFastMA && cacheDynamicTrendLine[idx].PeriodSlowMA == periodSlowMA && cacheDynamicTrendLine[idx].PeriodStableMA == periodStableMA && cacheDynamicTrendLine[idx].EqualsInput(input))
						return cacheDynamicTrendLine[idx];
			return CacheIndicator<DynamicTrendLine>(new DynamicTrendLine(){ PeriodFastMA = periodFastMA, PeriodSlowMA = periodSlowMA, PeriodStableMA = periodStableMA }, input, ref cacheDynamicTrendLine);
		}

		public VWAP VWAP(ISeries<double> input)
		{
			if (cacheVWAP != null)
				for (int idx = 0; idx < cacheVWAP.Length; idx++)
					if ( cacheVWAP[idx].EqualsInput(input))
						return cacheVWAP[idx];
			return CacheIndicator<VWAP>(new VWAP(), input, ref cacheVWAP);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.DynamicTrendLine DynamicTrendLine(int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(Input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.VWAP VWAP()
		{
			return indicator.VWAP(Input);
		}


		
		public Indicators.DynamicTrendLine DynamicTrendLine(ISeries<double> input , int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.VWAP VWAP(ISeries<double> input )
		{
			return indicator.VWAP(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.DynamicTrendLine DynamicTrendLine(int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(Input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.VWAP VWAP()
		{
			return indicator.VWAP(Input);
		}


		
		public Indicators.DynamicTrendLine DynamicTrendLine(ISeries<double> input , int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.VWAP VWAP(ISeries<double> input )
		{
			return indicator.VWAP(input);
		}

	}
}

#endregion
