#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private DynamicTrendLine[] cacheDynamicTrendLine;
		private FibMA[] cacheFibMA;
		private ImprovedMcGinleyDynamic[] cacheImprovedMcGinleyDynamic;
		private VWAP[] cacheVWAP;

		
		public DynamicTrendLine DynamicTrendLine(int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return DynamicTrendLine(Input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public FibMA FibMA()
		{
			return FibMA(Input);
		}

		public ImprovedMcGinleyDynamic ImprovedMcGinleyDynamic(int fPeriod)
		{
			return ImprovedMcGinleyDynamic(Input, fPeriod);
		}

		public VWAP VWAP()
		{
			return VWAP(Input);
		}


		
		public DynamicTrendLine DynamicTrendLine(ISeries<double> input, int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			if (cacheDynamicTrendLine != null)
				for (int idx = 0; idx < cacheDynamicTrendLine.Length; idx++)
					if (cacheDynamicTrendLine[idx].PeriodFastMA == periodFastMA && cacheDynamicTrendLine[idx].PeriodSlowMA == periodSlowMA && cacheDynamicTrendLine[idx].PeriodStableMA == periodStableMA && cacheDynamicTrendLine[idx].EqualsInput(input))
						return cacheDynamicTrendLine[idx];
			return CacheIndicator<DynamicTrendLine>(new DynamicTrendLine(){ PeriodFastMA = periodFastMA, PeriodSlowMA = periodSlowMA, PeriodStableMA = periodStableMA }, input, ref cacheDynamicTrendLine);
		}

		public FibMA FibMA(ISeries<double> input)
		{
			if (cacheFibMA != null)
				for (int idx = 0; idx < cacheFibMA.Length; idx++)
					if ( cacheFibMA[idx].EqualsInput(input))
						return cacheFibMA[idx];
			return CacheIndicator<FibMA>(new FibMA(), input, ref cacheFibMA);
		}

		public ImprovedMcGinleyDynamic ImprovedMcGinleyDynamic(ISeries<double> input, int fPeriod)
		{
			if (cacheImprovedMcGinleyDynamic != null)
				for (int idx = 0; idx < cacheImprovedMcGinleyDynamic.Length; idx++)
					if (cacheImprovedMcGinleyDynamic[idx].FPeriod == fPeriod && cacheImprovedMcGinleyDynamic[idx].EqualsInput(input))
						return cacheImprovedMcGinleyDynamic[idx];
			return CacheIndicator<ImprovedMcGinleyDynamic>(new ImprovedMcGinleyDynamic(){ FPeriod = fPeriod }, input, ref cacheImprovedMcGinleyDynamic);
		}

		public VWAP VWAP(ISeries<double> input)
		{
			if (cacheVWAP != null)
				for (int idx = 0; idx < cacheVWAP.Length; idx++)
					if ( cacheVWAP[idx].EqualsInput(input))
						return cacheVWAP[idx];
			return CacheIndicator<VWAP>(new VWAP(), input, ref cacheVWAP);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.DynamicTrendLine DynamicTrendLine(int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(Input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.FibMA FibMA()
		{
			return indicator.FibMA(Input);
		}

		public Indicators.ImprovedMcGinleyDynamic ImprovedMcGinleyDynamic(int fPeriod)
		{
			return indicator.ImprovedMcGinleyDynamic(Input, fPeriod);
		}

		public Indicators.VWAP VWAP()
		{
			return indicator.VWAP(Input);
		}


		
		public Indicators.DynamicTrendLine DynamicTrendLine(ISeries<double> input , int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.FibMA FibMA(ISeries<double> input )
		{
			return indicator.FibMA(input);
		}

		public Indicators.ImprovedMcGinleyDynamic ImprovedMcGinleyDynamic(ISeries<double> input , int fPeriod)
		{
			return indicator.ImprovedMcGinleyDynamic(input, fPeriod);
		}

		public Indicators.VWAP VWAP(ISeries<double> input )
		{
			return indicator.VWAP(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.DynamicTrendLine DynamicTrendLine(int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(Input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.FibMA FibMA()
		{
			return indicator.FibMA(Input);
		}

		public Indicators.ImprovedMcGinleyDynamic ImprovedMcGinleyDynamic(int fPeriod)
		{
			return indicator.ImprovedMcGinleyDynamic(Input, fPeriod);
		}

		public Indicators.VWAP VWAP()
		{
			return indicator.VWAP(Input);
		}


		
		public Indicators.DynamicTrendLine DynamicTrendLine(ISeries<double> input , int periodFastMA, int periodSlowMA, int periodStableMA)
		{
			return indicator.DynamicTrendLine(input, periodFastMA, periodSlowMA, periodStableMA);
		}

		public Indicators.FibMA FibMA(ISeries<double> input )
		{
			return indicator.FibMA(input);
		}

		public Indicators.ImprovedMcGinleyDynamic ImprovedMcGinleyDynamic(ISeries<double> input , int fPeriod)
		{
			return indicator.ImprovedMcGinleyDynamic(input, fPeriod);
		}

		public Indicators.VWAP VWAP(ISeries<double> input )
		{
			return indicator.VWAP(input);
		}

	}
}

#endregion
